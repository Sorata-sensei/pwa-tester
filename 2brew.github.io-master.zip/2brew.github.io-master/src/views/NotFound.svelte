<script>
  import Error from '../components/Error.svelte';

</script>

<Error error={{response: {status: 404, statusText: 'Not Found'}}}/>
